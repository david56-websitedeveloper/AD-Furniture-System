  // JavaScript
  function createSalesReceipt() {
    alert("Sales receipt creation is triggered!");
}
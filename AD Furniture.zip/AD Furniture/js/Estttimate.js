function createEstimate() {
    alert('Creating an estimate...');
  }
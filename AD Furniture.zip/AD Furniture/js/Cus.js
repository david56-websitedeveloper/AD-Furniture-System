    // JavaScript Functionality
    document.getElementById("add-customer").addEventListener("click", function () {
        alert("Thank you for clicking Add Customer Button!");
      });
  
      document.getElementById("floating-add").addEventListener("click", function () {
        alert("Floating Add Button clicked! Now you can add.");
      });

      
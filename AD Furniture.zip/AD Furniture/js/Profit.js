 // JavaScript
        // Add any required interactivity if needed
        console.log("Page loaded successfully");
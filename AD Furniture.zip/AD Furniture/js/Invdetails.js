 // JavaScript Functionality
 document.getElementById("create-invoice").addEventListener("click", function () {
    alert("Click Plus Button  and Other we getting soon!");
  });

  document.getElementById("floating-create").addEventListener("click", function () {
    alert("Floating Create Button clicked!");
  });
  
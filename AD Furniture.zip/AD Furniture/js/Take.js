document.getElementById('record-btn').addEventListener('click', function () {
    document.getElementById('record-section').classList.add('hidden');
    document.getElementById('payment-form').classList.remove('hidden');
  });
 // Function for button click
 function createExpense() {
    alert('Creating an expense...');
  }